/**
 * Simple Chat Processor Lambda Function
 * Provides basic chat functionality with frontend-aligned responses
 */

exports.handler = async (event, context) => {
  console.log('Simple chat processor invoked:', JSON.stringify(event, null, 2));

  try {
    const path = event.path;
    const method = event.httpMethod;

    // Route based on path and method
    if (method === 'POST' && path === '/chat') {
      // Process chat message
      if (!event.body) {
        return {
          statusCode: 400,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS'
          },
          body: JSON.stringify({
            error: 'Request body is required'
          })
        };
      }

      const request = JSON.parse(event.body);
      const message = request.message || '';
      const sessionId = request.sessionId || `session-${Date.now()}`;

      // Simple diabetes-related response logic
      let response = '';
      let confidence = 0.8;
      let escalated = false;
      let escalationReason = null;

      // Check for diabetes-related keywords
      const diabetesKeywords = ['diabetes', 'blood sugar', 'glucose', 'insulin', 'type 1', 'type 2'];
      const hasKeywords = diabetesKeywords.some(keyword => 
        message.toLowerCase().includes(keyword.toLowerCase())
      );

      // Check for escalation triggers
      const escalationKeywords = ['doctor', 'prescribe', 'medication', 'emergency', 'help me', 'person'];
      const needsEscalation = escalationKeywords.some(keyword => 
        message.toLowerCase().includes(keyword.toLowerCase())
      );

      if (needsEscalation) {
        response = "I understand you may need to speak with someone directly. While I can provide general information about diabetes, I cannot provide medical advice or prescriptions. Would you like to talk to a person from the American Diabetes Association?";
        confidence = 0.3;
        escalated = true;
        escalationReason = "User request requires human assistance";
      } else if (hasKeywords) {
        if (message.toLowerCase().includes('type 1')) {
          response = "Type 1 diabetes is an autoimmune condition where the pancreas produces little or no insulin. People with Type 1 diabetes need to take insulin daily to survive. It's usually diagnosed in children and young adults, but can occur at any age.";
        } else if (message.toLowerCase().includes('type 2')) {
          response = "Type 2 diabetes is the most common form of diabetes. It occurs when your body doesn't use insulin properly or doesn't make enough insulin. It can often be managed with lifestyle changes, medication, and sometimes insulin.";
        } else if (message.toLowerCase().includes('blood sugar') || message.toLowerCase().includes('glucose')) {
          response = "Blood sugar (glucose) management is crucial for people with diabetes. Normal blood sugar levels are typically 80-130 mg/dL before meals and less than 180 mg/dL after meals. Regular monitoring helps you understand how food, activity, and medication affect your levels.";
        } else if (message.toLowerCase().includes('insulin')) {
          response = "Insulin is a hormone that helps your body use glucose for energy. People with Type 1 diabetes must take insulin, and some people with Type 2 diabetes also need insulin. There are different types of insulin that work at different speeds and for different lengths of time.";
        } else {
          response = "Diabetes is a group of diseases that result in too much sugar in the blood (high blood glucose). The main types are Type 1, Type 2, and gestational diabetes. Each type has different causes and treatments, but all can be managed with proper care.";
        }
        confidence = 0.9;
      } else {
        response = "I'm here to help with questions about diabetes. I can provide information about diabetes types, management, blood sugar, insulin, and general diabetes care. What would you like to know about diabetes?";
        confidence = 0.6;
      }

      // Mock sources
      const sources = [
        {
          url: 'https://diabetes.org/about-diabetes',
          title: 'About Diabetes | American Diabetes Association',
          excerpt: 'Learn about diabetes types, symptoms, causes, and management from the leading diabetes organization.'
        },
        {
          url: 'https://diabetes.org/living-with-diabetes',
          title: 'Living with Diabetes | ADA',
          excerpt: 'Tips and resources for daily diabetes management and living a healthy life with diabetes.'
        }
      ];

      // Return frontend-expected format
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
          'Access-Control-Allow-Methods': 'POST, GET, OPTIONS'
        },
        body: JSON.stringify({
          response: response,
          confidence: confidence,
          sources: sources,
          escalated: escalated,
          escalationReason: escalationReason,
          sessionId: sessionId,
          language: 'en',
          timestamp: new Date().toISOString()
        })
      };

    } else if (method === 'GET' && path === '/chat/history') {
      // Get chat history
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        },
        body: JSON.stringify({
          sessions: [
            {
              sessionId: 'session-1',
              startTime: '2024-12-30T10:00:00Z',
              lastActivity: '2024-12-30T10:30:00Z',
              messageCount: 5,
              language: 'en',
              summary: 'Questions about Type 1 diabetes management'
            }
          ],
          total: 1
        })
      };

    } else if (method === 'GET' && path === '/chat/sessions') {
      // Get user sessions (alias for /chat/history)
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        },
        body: JSON.stringify({
          sessions: [
            {
              sessionId: 'session-1',
              startTime: '2024-12-30T10:00:00Z',
              lastActivity: '2024-12-30T10:30:00Z',
              messageCount: 5,
              language: 'en',
              summary: 'Questions about Type 1 diabetes management'
            }
          ],
          total: 1
        })
      };

    } else if (method === 'GET' && (path === '/chat' || path === '/health')) {
      // Health check
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          status: 'healthy',
          service: 'simple-chat-processor',
          timestamp: new Date().toISOString(),
          features: ['chat', 'history', 'sessions']
        })
      };

    } else if (method === 'OPTIONS') {
      // CORS preflight
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization',
          'Access-Control-Allow-Methods': 'POST, GET, OPTIONS'
        },
        body: ''
      };

    } else {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          error: 'Endpoint not found',
          availableEndpoints: [
            'POST /chat',
            'GET /chat/history',
            'GET /chat/sessions',
            'GET /health'
          ]
        })
      };
    }
  } catch (error) {
    console.error('Simple chat processor error:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message || 'Unknown error'
      })
    };
  }
};